/* Overview: This program is intended to be able to load a vector with emails, display the emails, 
 * check if an individual email is spam, and filter real emails from a list of known spam addresses.
 * Author: Angelo Sfyris
 * Date: 1/17/2020
 * Course: CS 251, UIC */
 
#include <iostream>
#include <fstream>
#include <string>
#include "ourvector.h"
using namespace std;


/* Name: binarySearch()
 * Overview: Binary searches through a sorted list in O(log_2 n) time
 * Parameters: a string, an ourvector
 * Return type: boolean */
bool binarySearch(string newEmailSpecific, ourvector<string>& emailList){
   int low = 0;
   int high = emailList.size()-1;
   int mid;
   string middle;
    
      while (low <= high){      
          mid = (high+low)/2;        
          middle = emailList[mid];
          
          if (newEmailSpecific == middle) { return true; } // Element found
          
          // Shrink to lower bound
          if (newEmailSpecific < middle)
          {
               high = mid-1;               
          }
          // Shrink to upper bound
          else if (newEmailSpecific > middle)
          {
               low = mid+1;                
          }         
      }    
   
   return false; // Not found
}


/* Name: separateEmail()
 * Overview: breaks up an email into its domain and username
 * Parameters: a string, a string, a string
 * Return type: void */
void separateEmail(string email, string& username, string& domain){
   int position;  
   position = email.find("@");
   username = email.substr(0,position);
   domain = email.substr(position+1);
}


/* Name: buildSpamEmail()
 * Overview: constructs an email in the format of the text file spam addresses 
 * Parameters: a string, a string, a string, a string
 * Return type: void */
void buildSpamEmail(string username, string domain, string& newEmailGeneric, string& newEmailSpecific){
    newEmailGeneric = domain + ":*";
    newEmailSpecific = domain + ":" + username;   
}


/* Name: loadSpam()
 * Overview: Loads all emails into an ourvector
 * Parameters: an ourvector, a string
 * Return type: void */
void loadSpam(ourvector<string> &email, string filename){ 
    ifstream emailStream;
    string input;
    
    // clears when there is already a loaded vector
    if (email.size() > 0) { email.clear(); }
    
    // Opens file and checks for success
    emailStream.open(filename);
    if (!emailStream.is_open()) {
       cout << "**Error, unable to open \'" << filename << "\'" << endl; 
       return;
    }
    cout << "Loading \'" << filename << "\'" << endl;
    
    // Reads in file data
    while (!emailStream.eof()){     
       getline(emailStream, input);
       if (!emailStream.fail()) {        
          email.push_back(input);   
        }
    }
    cout << "# of spam entries: " << email.size() << endl << endl;
}


/* Name: displayList()
 * Overview: Prints all emails contained within a vector
 * Parameters: an ourvector, a boolean
 * Return type: void */
void displayList(ourvector<string>& emailList, bool empty)
{
   for (auto x : emailList) { cout << x << endl;  empty = false;} 
   if (empty == true) { cout << endl; } // Special case for when display is empty (formatting)
}


/* Name: checkIfSpam()
 * Overview: Checks whether or not a single email is spam 
 * Parameters: a string, an ourvector 
 * Return type: boolean */
bool checkIfSpam(string email, ourvector<string>& emailList){
    bool spam;
    string username, domain, newEmailGeneric, newEmailSpecific;

    separateEmail(email, username, domain);
    buildSpamEmail(username, domain, newEmailGeneric, newEmailSpecific);
    
    // Checks both version of spam email format 
    if (binarySearch(newEmailSpecific, emailList)){ spam = true; } 
    else if (binarySearch(newEmailGeneric, emailList)){ spam = true; }
    else { spam = false; }

    return spam;
}


/* Name: filterSpam() 
 * Overview: Filters out real emails from the spam 
 * Parameters: a string, a string, an ourvector 
 * Return type: void */
void filterSpam(string emailFile, string outputFile, ourvector<string>& emailList){
    string emailNumber, emailToExport, emailText;
    ifstream inputStream;
    int totalEmailCounter = 0;
    int processedEmailCounter = 0;
      
    // Opens file and checks for success
    inputStream.open(emailFile);
    if (!inputStream.is_open()) {
       cout << "**Error, unable to open \'" << emailFile << "\'" << endl;   
       return;
    }    
    
    // Opens output stream to specified file
    ofstream outfile(outputFile);
            if (!outfile.good()){
               cout << "**Error, unable to open \'" << outputFile << "\'" << endl;       
            }
    
    // Reads in file data
    inputStream >> emailNumber;    
    while (!inputStream.eof()){       
       inputStream >> emailToExport;      
       getline(inputStream, emailText);      
        
       // Writes the email to file if all conditions are met 
       if (!inputStream.fail()) {           
          totalEmailCounter++;
          if (!checkIfSpam(emailToExport, emailList)){              
            processedEmailCounter++;            
            outfile << emailNumber << " " << emailToExport << " " << emailText << endl;            
          }
       }
       inputStream >> emailNumber;
    }
    outfile.close();
    
    cout << "# emails processed: " << totalEmailCounter << endl;
    cout << "# non-spam emails:  " << processedEmailCounter << endl << endl;

}


/* Name: main()
 * Overview: Function that runs the program 
 * Parameters: None
 * Return type: integer */
int main() {  
   ourvector<string> spamList;
   string command, filename, email, outputFile;
   bool isEmpty = true; 
    
   cout << "** Welcome to spam filtering app **" << endl << endl; // Opening message
    
   while (command != "#"){
       
       cout << "Enter command or # to exit> "; // Menu screen
       cin >> command;             
       
       // List of menu commands
       if (command == "#"){ break; }
       else if (command == "load"){
           cin >> filename;
           loadSpam(spamList, filename);
       }
       else if (command == "display"){
           displayList(spamList, isEmpty);
       }
       else if (command == "check"){
           cin >> email;
           
           if (checkIfSpam(email, spamList)){
               cout << email << " is spam" << endl << endl;
           }
           else {
               cout << email << " is not spam" << endl << endl;
           }
       }
       else if (command == "filter"){
           cin >> filename;
           cin >> outputFile;
           filterSpam(filename, outputFile, spamList);
       }
       else {
           cout << "**invalid command" << endl;
       }              
   }   
   return 0;
}